# 使用示例
准备：`python scripts/review_pipeline.py prepare --input reviews.xlsx --out work --file-index 1 --product-id B0CRTPHGQN`
智能体逐条阅读 `work/parsed_reviews.csv`，依据 references/annotation_schema.json 写入 `work/annotations.jsonl`（每行一个 JSON 对象，不能复制示例数据作为真实标注）。
审计：`python scripts/review_pipeline.py audit --parsed work/parsed_reviews.csv --annotations work/annotations.jsonl --out work/audit`
注意：对用户已经给出 record_id 的 F2 100 条测试集，应保留现有 ID，不要重新 prepare 生成新编号。MVP 解析器适用于未经编号的原始 Excel/CSV；带已有 ID 的 CSV 应按原编号直接进入标注。

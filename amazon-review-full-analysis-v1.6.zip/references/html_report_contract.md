# v1.5 HTML 数据契约（处理流程 v1.6）
report_content.json 包含 product_name、subtitle、audit:{passed:true}、findings[3..5]、scenes[至少1]、recommendations[3..5]。
每个 scene 包含 name、dimensions 八个字段（人群定位、空间、情境、用户目标、产品需求、当前痛点、未被满足的需求、优化建议）。每个场景至少3维有实质内容，其他维允许明确说明证据不足；不得捏造内容。
先通过 review_pipeline.py audit 并核对 audit.json，再生成 report_content.json。不能只手写 audit.passed=true 充当审计。
唯一命令：python scripts/render_html.py --data report_content.json --out report.html
验收命令：python scripts/validate_report.py report.html --data report_content.json
校验器重放渲染并逐字节比较，不允许自行拼写 HTML。

# 紧凑标注输出协议（JSONL）
每条评论输出且只输出一条JSON，不要附加逐条长篇说明；必须保留以下字段以兼容 `scripts/review_pipeline.py audit`：
`record_id`, `classification`（有效/低信息量/无效）, `reason`（不超过30汉字但必须有真实语义理由）, `language`, `main_scene`（有效评论必须填场景码或未归类）, `secondary_scenes`（数组）, `pain_points`（数组）, `evidence`（数组，短原文片段）, `annotation_version`（与 parsed_reviews.csv 中 annotation_version 一致，默认 v1.6）, `product_id`。
痛点数组对象：`code`（仅语义完全匹配时复用历史SP码，否则使用商品特有XP_码）, `theme`（对应PT或XP_主题）, `mapping_status`（已确认/待判定）, `evidence`（原文短片段）, `reason`（精炼理由）。
无痛点可为空数组；低信息量、无效的pain_points必须为空；不得因为好评就臆造痛点。未知码不许静默丢弃。保留`source_row`于解析文件即可，不必每条重复。
若某条含多个不同痛点分别记录；同一主题重复提及仅保留一次。先标注事实，再统一跨批归并。
示例（虚构示意，禁止当作真实评论）：
`{"record_id":"F1S1R0002","classification":"有效","reason":"指出具体结构缺陷","language":"en","main_scene":"未归类","secondary_scenes":[],"pain_points":[{"code":"XP_drawer_slide","theme":"XP_drawer_slide","mapping_status":"已确认","evidence":"drawer sticks","reason":"抽屉滑动阻滞"}],"evidence":["drawer sticks"],"annotation_version":"v1.2","product_id":"EXAMPLE"}`

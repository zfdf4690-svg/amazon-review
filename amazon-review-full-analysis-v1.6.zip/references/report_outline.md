# v1.5 唯一报告结构（旧八章节大纲已废弃）

HTML 顶部：产品标题与简短副标题。
正文仅有三个板块：①关键业务发现（3–5项）②场景级八维度分析（各场景固定八维）③行动建议（3–5项）。
禁止增加痛点排行榜、方法、附录、图表或导航等独立板块。必要数字放入现有三板块。
唯一生成器 scripts/render_html.py，必须用 scripts/validate_report.py --data report_content.json 重放验收。

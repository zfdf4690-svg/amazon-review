#!/usr/bin/env python3
"""Fail closed if a report is not produced by the locked renderer."""
import pathlib,sys,re,argparse,json
from render_html import render
from html.parser import HTMLParser
class P(HTMLParser):
 def __init__(self): super().__init__();self.sections=0;self.labels=[];self.inh2=False;self.h2='';self.marker=False;self.dims=[];self.in_dim=False;self.dim='';self.scene_count=0
 def handle_starttag(self,t,a):
  d=dict(a);c=d.get('class','').split()
  if t=='meta' and d.get('name')=='report-template' and d.get('content')=='amazon-review-locked-v1.5':self.marker=True
  if t=='section' and 'panel' in c:self.sections+=1
  if t=='h2':self.inh2=True;self.h2=''
  if t=='article' and 'scene' in c:self.scene_count+=1
  if t=='div' and 'dim-label' in c:self.in_dim=True;self.dim=''
 def handle_data(self,d):
  if self.inh2:self.h2+=d
  if self.in_dim:self.dim+=d
 def handle_endtag(self,t):
  if t=='h2' and self.inh2:self.labels.append(self.h2.strip());self.inh2=False
  if t=='div' and self.in_dim:self.dims.append(self.dim.strip());self.in_dim=False
def main():
 ap=argparse.ArgumentParser();ap.add_argument('html');ap.add_argument('--data',required=True,help='用于重放对比的 report_content.json');args=ap.parse_args()
 s=pathlib.Path(args.html).read_text(encoding='utf-8');p=P();p.feed(s)
 d=json.loads(pathlib.Path(args.data).read_text(encoding='utf-8'))
 assert s==render(d),'HTML与固定渲染器重放结果不一致（拒绝自写报告）'
 assert p.marker,'不是v1.5强制模板生成的HTML'
 assert p.sections==3,(p.sections,'必须恰好3个主板块')
 assert p.labels==['关键业务发现','场景级八维度分析','行动建议'],p.labels
 assert p.scene_count>=1,'缺少场景'
 assert len(p.dims)==p.scene_count*8,(len(p.dims),p.scene_count)
 assert len(re.findall(r'<article class="finding">',s)) in (3,4,5),'业务发现数量不符'
 assert len(re.findall(r'<article class="action">',s)) in (3,4,5),'行动建议数量不符'
 print('PASS: locked layout, 3 sections, 8 dimensions per scene')
if __name__=='__main__':main()

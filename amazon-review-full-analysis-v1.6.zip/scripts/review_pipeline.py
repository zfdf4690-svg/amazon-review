#!/usr/bin/env python3
"""Deterministic Amazon review ingestion, OCR record merging and annotation audit. Python 3.9+."""
import argparse, collections, csv, hashlib, html, json, re
from pathlib import Path

FIELDS = {'title':['title','标题','review title','标题 翻译','标题(翻译)','标题（翻译）'], 'content':['content','内容','review content','review body','正文','内容 翻译','内容(翻译)','内容（翻译）','评论内容','评论正文'], 'rating':['rating','星级','评分','star','stars','星数','评分 星级']}
SP_PT={'SP01':'PT01','SP02':'PT01','SP03':'PT02','SP04':'PT02','SP05':'PT03','SP06':'PT04','SP07':'PT05','SP08':'PT06','SP09':'PT07','SP10':'PT08','SP11':'PT09','SP12':'PT10','SP13':'PT11','SP14':'PT05','SP15':'PT06','SP16':'PT05','SP17':'PT12','SP18':'PT06'}
PARSED_FIELDS=['record_id','source_type','source_file','source_ref','sheet','source_row','title','content','rating','product_id','annotation_version','duplicate_candidate','raw_title','raw_content']

def norm(v):
    return re.sub(r'\s+',' ',str(v or '').strip().lower().replace('_',' '))

def fieldmap(header):
    vals=[norm(v) for v in header]; found={}
    for key,aliases in FIELDS.items():
        hits=[i for i,v in enumerate(vals) if v in aliases]
        if hits:found[key]=hits[0]
    # Title and rating are optional for social data, but tabular Amazon input requires Content only.
    if 'content' not in found:raise ValueError('缺少评论正文 Content 列')
    return found

def detect_header(rows):
    for i,row in enumerate(rows[:10]):
        try:
            m=fieldmap(row)
            if len(m)>=2:return i,m
        except ValueError:pass
    raise ValueError('前10行未找到包含评论正文及标题/星级的表头')

def clean_text(v):
    raw=str(v if v is not None else '').strip()
    return re.sub(r'<[^>]+>',' ',html.unescape(raw)).replace('\xa0',' ').strip()

def rating_value(raw):
    s=str(raw or '').strip()
    if not s:return '',None
    m=re.fullmatch(r'([1-5])(?:\.0)?\s*(?:星|stars?)?',s,re.I)
    return (int(m.group(1)),None) if m else ('','invalid_rating')

def load_rows(path):
    p=Path(path)
    if p.suffix.lower()=='.csv':
        last=None
        for encoding in ('utf-8-sig','gb18030'):
            try:
                with p.open(encoding=encoding,newline='') as f: rows=list(csv.reader(f))
                yield 1,'Sheet1',rows,encoding
                return
            except UnicodeDecodeError as e:last=e
        raise ValueError('CSV 编码无法识别（尝试 utf-8-sig、gb18030）') from last
    elif p.suffix.lower() in ('.xlsx','.xlsm'):
        try:import openpyxl
        except ImportError as e:raise RuntimeError('Excel 解析需要 openpyxl') from e
        wb=openpyxl.load_workbook(p,read_only=True,data_only=True)
        try:
            for idx,sh in enumerate(wb.worksheets,1):yield idx,sh.title,list(sh.values),'xlsx'
        finally:wb.close()
    else:raise ValueError('仅支持 CSV/XLSX/XLSM')

def writecsv(path,rows,fields):
    with Path(path).open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(rows)

def readcsv(path):
    with Path(path).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))

def prepare(args):
    out=Path(args.out);out.mkdir(parents=True,exist_ok=True)
    result=[];issues=[];sheets=[]
    for sidx,sheet,rows,encoding in load_rows(args.input):
        if not rows:
            sheets.append({'sheet':sheet,'status':'skipped_empty','data_rows':0});continue
        try:hidx,m=detect_header(rows)
        except ValueError as e:
            sheets.append({'sheet':sheet,'status':'skipped_no_review_header','reason':str(e),'physical_rows':len(rows)})
            issues.append({'sheet':sheet,'issue':'non_data_sheet','detail':str(e)})
            continue
        blank=0
        for rowno,row in enumerate(rows[hidx+1:],hidx+2):
            def val(key):
                idx=m.get(key)
                return str(row[idx] if idx is not None and idx<len(row) and row[idx] is not None else '').strip()
            title,content,rawrating=val('title'),val('content'),val('rating')
            if not any((title,content,rawrating)):blank+=1;continue
            rid=f'F{args.file_index}S{sidx}R{rowno:04d}'
            rating,err=rating_value(rawrating)
            if err:issues.append({'record_id':rid,'issue':err,'value':rawrating})
            if not title and not content:issues.append({'record_id':rid,'issue':'missing_title_and_content'})
            result.append(dict(record_id=rid,source_type='amazon',source_file=Path(args.input).name,source_ref=f'{sheet}:{rowno}',sheet=sheet,source_row=rowno,title=clean_text(title),content=clean_text(content),rating=rating,product_id=args.product_id or '',annotation_version=args.version,duplicate_candidate='',raw_title=title,raw_content=content))
        sheets.append({'sheet':sheet,'status':'parsed','header_row':hidx+1,'field_mapping':m,'data_rows':len(rows)-hidx-1,'blank_rows':blank,'parsed_rows':len(rows)-hidx-1-blank,'encoding':encoding})
    if not result:raise ValueError('没有解析到评论记录；请检查数据 Sheet 和表头')
    ids=[r['record_id'] for r in result]
    if len(ids)!=len(set(ids)):raise ValueError('评论编号发生冲突')
    writecsv(out/'parsed_reviews.csv',result,PARSED_FIELDS)
    manifest={'source':str(args.input),'sha256':hashlib.sha256(Path(args.input).read_bytes()).hexdigest(),'parsed_count':len(result),'unique_ids':len(set(ids)),'sheets':sheets,'issues':issues,'version':args.version}
    (out/'input_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'parsed_count':len(result),'issues':len(issues),'output':str(out)},ensure_ascii=False))

def merge(args):
    """Accept *verified structured* OCR records, not raw images. Never claim OCR ran here."""
    base=readcsv(args.parsed)
    data=json.loads(Path(args.ocr_json).read_text(encoding='utf-8'))
    if not isinstance(data,dict) or not isinstance(data.get('reviews'),list):raise ValueError('OCR JSON 必须包含 reviews 数组')
    out=Path(args.out);out.mkdir(parents=True,exist_ok=True)
    seen={r['record_id'] for r in base};text_index=collections.defaultdict(list)
    for r in base:
        if r.get('content'):text_index[norm(r['content'])].append(r['record_id'])
    additions=[];issues=[]
    for i,item in enumerate(data['reviews'],1):
        if not isinstance(item,dict):issues.append({'index':i,'issue':'invalid_record'});continue
        content=str(item.get('content') or '').strip()
        source_file=str(item.get('source_file') or '').strip()
        source_ref=str(item.get('source_ref') or '').strip()
        if not content or not source_file or not source_ref or item.get('boundary_confidence')=='uncertain':
            issues.append({'index':i,'source_file':source_file,'issue':'unconfirmed_ocr_record','reason':'缺正文/来源定位或评论边界不确定'});continue
        rid=f'F{args.file_index}S1R{i:04d}'
        if rid in seen:raise ValueError(f'合并编号冲突: {rid}；请调整 --file-index')
        rating,err=rating_value(item.get('rating'))
        if err:issues.append({'index':i,'issue':err,'value':item.get('rating')})
        clean=clean_text(content)
        dup='|'.join(text_index[norm(clean)])
        row=dict(record_id=rid,source_type='screenshot',source_file=source_file,source_ref=source_ref,sheet='OCR',source_row=i,title=clean_text(item.get('title')),content=clean,rating=rating,product_id=args.product_id or (base[0].get('product_id') if base else ''),annotation_version=args.version or (base[0].get('annotation_version') if base else 'v1.6'),duplicate_candidate=dup,raw_title=str(item.get('title') or ''),raw_content=content)
        additions.append(row);seen.add(rid);text_index[norm(clean)].append(rid)
    combined=base+additions
    writecsv(out/'parsed_reviews.csv',combined,PARSED_FIELDS)
    manifest={'base_count':len(base),'ocr_candidates':len(data['reviews']),'ocr_added':len(additions),'ocr_unconfirmed':sum(x['issue']=='unconfirmed_ocr_record' for x in issues),'combined_count':len(combined),'unique_ids':len(seen),'issues':issues,'source':'structured_ocr_json','ocr_executed_by_this_script':False}
    (out/'input_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(manifest,ensure_ascii=False,indent=2))

def audit(args):
    out=Path(args.out);out.mkdir(parents=True,exist_ok=True)
    parsed=readcsv(args.parsed)
    annotations=[json.loads(line) for line in Path(args.annotations).read_text(encoding='utf-8-sig').splitlines() if line.strip()]
    errors=[];warnings=[];source={r['record_id']:r for r in parsed};counts=collections.Counter(a.get('record_id') for a in annotations)
    if len(source)!=len(parsed):errors.append('解析数据 record_id 重复')
    for rid,n in counts.items():
        if n!=1:errors.append(f'{rid}: 标注重复 {n} 次')
        if rid not in source:errors.append(f'{rid}: 标注 ID 不存在于解析集')
    missing=set(source)-set(counts)
    if missing:errors.append(f'未标注 {len(missing)} 条: '+','.join(sorted(missing)[:20]))
    class_counts=collections.Counter();theme_ids=collections.defaultdict(set);theme_low=collections.defaultdict(set);recon=collections.defaultdict(lambda:collections.Counter());special=collections.Counter()
    for a in annotations:
        rid=a.get('record_id');row=source.get(rid)
        if not row:continue
        cls=a.get('classification');class_counts[cls]+=1
        if cls not in ('有效','低信息量','无效'):errors.append(f'{rid}: 分类非法 {cls}')
        if not a.get('reason'):errors.append(f'{rid}: 缺少分类理由')
        if a.get('annotation_version')!=row.get('annotation_version'):errors.append(f'{rid}: 标注版本与输入不一致')
        if a.get('source_type') and a['source_type']!=row.get('source_type'):errors.append(f'{rid}: 来源类型不一致')
        scene=a.get('main_scene')
        if cls=='有效' and not scene:errors.append(f'{rid}: 有效评论缺少主场景（无归属须填 未归类）')
        if scene and scene!='未归类' and not re.fullmatch(r'S(?:[1-9]|10|11)|XS_[A-Za-z0-9_]+',str(scene)):errors.append(f'{rid}: 场景码非法 {scene}')
        for sub in a.get('secondary_scenes',[]):
            if sub!='未归类' and not re.fullmatch(r'S(?:[1-9]|10|11)|XS_[A-Za-z0-9_]+',str(sub)):errors.append(f'{rid}: 副场景码非法 {sub}')
        pts=a.get('pain_points',[])
        if not isinstance(pts,list):errors.append(f'{rid}: pain_points 必须是数组');continue
        if cls!='有效' and pts:errors.append(f'{rid}: 非有效评论不可计痛点')
        if cls=='有效' and not isinstance(a.get('evidence'),list):errors.append(f'{rid}: 缺少 evidence 数组')
        seen=set()
        for p in pts:
            if not isinstance(p,dict):errors.append(f'{rid}: 痛点格式错误');continue
            code=p.get('code','');pt=p.get('theme','');status=p.get('mapping_status','')
            if code in SP_PT:
                if SP_PT[code]!=pt:errors.append(f'{rid}: {code} 不应映射 {pt}')
            elif re.fullmatch(r'XP_[A-Za-z0-9_]+',str(code)):
                if not str(pt).startswith('XP_'):errors.append(f'{rid}: 商品特有主题须使用 XP_ 命名空间')
                if not p.get('reason'):errors.append(f'{rid}: 商品特有痛点需定义和理由')
            else:errors.append(f'{rid}: 未知痛点码 {code}')
            if status not in ('已确认','待判定'):errors.append(f'{rid}: 映射状态非法 {status}')
            if not p.get('evidence'):errors.append(f'{rid}: {code} 缺少证据')
            if pt in seen:continue
            seen.add(pt)
            if cls=='有效' and status=='已确认':
                theme_ids[pt].add(rid)
                if str(row.get('rating')) in ('1','2'):theme_low[pt].add(rid)
                recon[pt]['无场景' if scene=='未归类' else '有场景']+=1
            elif status=='待判定':special[pt]+=1
    valid=class_counts['有效'];stats=[];reconciliation=[]
    for pt,ids in theme_ids.items():
        n=len(ids);low=len(theme_low[pt]);yes=recon[pt]['有场景'];no=recon[pt]['无场景']
        stats.append({'theme':pt,'count':n,'valid_denominator':valid,'frequency_pct':round(100*n/valid,2) if valid else 0,'low_star_count':low,'record_ids':'|'.join(sorted(ids))})
        reconciliation.append({'theme':pt,'with_scene':yes,'without_scene':no,'total':n,'balanced':yes+no==n})
        if yes+no!=n:errors.append(f'{pt}: 场景归属对账不平')
    stats.sort(key=lambda x:(-x['count'],x['theme']))
    if sum(class_counts.values())!=len(parsed):errors.append('三分数量与解析数不一致')
    if special:warnings.append('待判定映射不计入已确认主题频次：'+str(dict(special)))
    writecsv(out/'theme_stats.csv',stats,['theme','count','valid_denominator','frequency_pct','low_star_count','record_ids'])
    writecsv(out/'reconciliation.csv',reconciliation,['theme','with_scene','without_scene','total','balanced'])
    report={'passed':not errors,'parsed_count':len(parsed),'annotated_count':len(annotations),'class_counts':dict(class_counts),'source_counts':dict(collections.Counter(r.get('source_type','unknown') for r in parsed)),'confirmed_theme_count':len(stats),'errors':errors,'warnings':warnings,'note':'仅核验结构、计数与映射；语义归并仍需人工抽查'}
    (out/'audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False,indent=2))
    if errors:raise SystemExit(2)

def main():
    ap=argparse.ArgumentParser();sub=ap.add_subparsers(dest='command',required=True)
    p=sub.add_parser('prepare');p.add_argument('--input',required=True);p.add_argument('--out',required=True);p.add_argument('--file-index',type=int,default=1);p.add_argument('--product-id',default='');p.add_argument('--version',default='v1.6');p.set_defaults(func=prepare)
    m=sub.add_parser('merge-ocr');m.add_argument('--parsed',required=True);m.add_argument('--ocr-json',required=True);m.add_argument('--out',required=True);m.add_argument('--file-index',type=int,default=2);m.add_argument('--product-id',default='');m.add_argument('--version',default='');m.set_defaults(func=merge)
    a=sub.add_parser('audit');a.add_argument('--parsed',required=True);a.add_argument('--annotations',required=True);a.add_argument('--out',required=True);a.set_defaults(func=audit)
    args=ap.parse_args()
    try:args.func(args)
    except (ValueError,RuntimeError,FileNotFoundError) as e:ap.exit(1,f'处理失败：{e}\n')
if __name__=='__main__':main()

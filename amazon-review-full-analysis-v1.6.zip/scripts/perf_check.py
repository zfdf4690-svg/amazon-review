#!/usr/bin/env python3
"""Validate REAL end-to-end stage timestamps; never generate synthetic measurements."""
import argparse,datetime,json,pathlib
STAGES=["start","parsed","annotated","merged","audited","reported"]
def dt(v):
    d=datetime.datetime.fromisoformat(v.replace("Z","+00:00"))
    if d.tzinfo is None: raise ValueError("时间必须含时区")
    return d
def main():
    p=argparse.ArgumentParser()
    p.add_argument("--log",required=True);p.add_argument("--out",required=True);p.add_argument("--count",type=int,default=100)
    a=p.parse_args()
    raw=json.loads(pathlib.Path(a.log).read_text(encoding="utf-8"))
    missing=[k for k in STAGES if not raw.get(k)]
    if missing:
        result={"status":"未测","reason":"缺少真实时间戳: "+",".join(missing),"sla_seconds":180}
    else:
        stamps=[dt(raw[k]) for k in STAGES]
        seconds=[round((y-x).total_seconds(),2) for x,y in zip(stamps,stamps[1:])]
        if any(x<0 for x in seconds):raise ValueError("时间戳顺序错误")
        total=round((stamps[-1]-stamps[0]).total_seconds(),2)
        result={"status":"已计时","count":a.count,"stage_seconds":dict(zip(["parse","annotate","merge","audit","report"],seconds)),"total_seconds":total,"sla_seconds":180,"meets_100_review_sla":total<=180 if a.count==100 else None,"note":"性能达标不代表质量验收通过，须同时检查audit.json"}
    pathlib.Path(a.out).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding="utf-8")
    print(json.dumps(result,ensure_ascii=False))
if __name__=="__main__":main()

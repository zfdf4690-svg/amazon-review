#!/usr/bin/env python3
"""v1.5 locked-layout offline HTML renderer; v1.6 data pipeline."""
import argparse, html, json, pathlib

def esc(v): return html.escape(str(v if v is not None else ''), quote=True)
def pick(obj, *keys):
    for k in keys:
        if k in obj and obj[k] not in (None, ''): return obj[k]
    return ''

def evidence(items):
    chunks=[]
    for e in (items or [])[:3]:
        if not isinstance(e,dict):continue
        q=pick(e,'quote','text'); rid=pick(e,'record_id','review_id','id')
        if q: chunks.append(f'<div class="quote"><span class="rid">{esc(rid)}</span><span>{esc(q)}</span></div>')
    return ('<details class="evidence"><summary>查看评论依据</summary>'+''.join(chunks)+'</details>') if chunks else ''

DIMENSIONS=[('人群定位',('人群定位','人群','用户人群')),('空间',('空间','物理空间')),('情境',('情境','使用情境')),('用户目标',('用户目标','目标')),('产品需求',('产品需求','需求')),('当前痛点',('当前痛点','痛点')),('未被满足的需求',('未被满足的需求','未满足需求')),('优化建议',('优化建议','建议'))]
CSS=r'''*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;background:#f7f8f6;color:#23383c;font:16px/1.75 -apple-system,BlinkMacSystemFont,"Segoe UI","Microsoft YaHei","PingFang SC",sans-serif} .hero{background:#12353b;color:white;padding:52px 24px 60px}.hero-inner{max-width:1040px;margin:auto}.eyebrow{font-size:12px;letter-spacing:.12em;color:#e8c58b;font-weight:700}.hero h1{font-size:clamp(28px,4vw,40px);line-height:1.32;margin:15px 0 8px}.hero p{color:#d8e4e3;margin:0;max-width:720px}.wrap{max-width:1080px;padding:0 20px;margin:36px auto 70px}.panel{background:white;border:1px solid #e6ebe8;border-radius:18px;padding:32px;margin:0 0 28px;box-shadow:0 4px 18px rgba(20,45,43,.035)}.section-head{display:flex;align-items:baseline;gap:15px;border-bottom:1px solid #e8edea;padding-bottom:17px;margin-bottom:22px}.section-no{font-size:13px;color:#a16a28;font-weight:750;letter-spacing:.06em}.section-head h2{margin:0;font-size:25px;line-height:1.35}.finding{display:grid;grid-template-columns:44px 1fr;gap:15px;padding:21px 0;border-bottom:1px solid #edf0ed}.finding:last-child{border-bottom:0}.ordinal{font-weight:750;color:#aa7b3b;font-size:19px}.finding h3,.action h3{margin:0 0 6px;font-size:18px;line-height:1.5}.finding p,.action p{margin:0;color:#526166}.scene{border:1px solid #e2e9e5;border-radius:14px;overflow:hidden;margin:0 0 24px}.scene:last-child{margin-bottom:0}.scene-header{background:#173b40;color:white;padding:18px 23px;display:flex;justify-content:space-between;align-items:center;gap:12px}.scene-header h3{font-size:19px;margin:0}.scene-header small{color:#d2dfdd;font-size:13px}.dims{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px;padding:16px}.dim{padding:17px 18px;background:#f6f8f7;border-radius:10px;min-width:0}.dim-label{font-size:13px;font-weight:750;color:#98713f;margin-bottom:7px}.dim p{margin:0;overflow-wrap:anywhere}.evidence{margin-top:12px;font-size:13px;color:#536267}.evidence summary{cursor:pointer;color:#41685f;font-weight:650}.quote{background:#fff;border-left:3px solid #b58a50;margin:8px 0;padding:8px 11px;overflow-wrap:anywhere}.rid{display:block;font-size:12px;color:#a16a28;font-weight:700}.action{display:grid;grid-template-columns:48px 1fr;gap:16px;padding:22px 0;border-bottom:1px solid #edf0ed}.action:last-child{border:0}.action .ordinal{background:#eef3ef;border-radius:9px;text-align:center;padding:6px 0;color:#38675e}.action .meta{margin-top:7px}.action .meta b{color:#274b47}.empty{color:#75817e;font-style:italic}@media(max-width:700px){body{font-size:15px}.hero{padding:36px 20px 43px}.wrap{padding:0 12px;margin:18px auto}.panel{padding:22px 17px;border-radius:13px}.section-head h2{font-size:21px}.dims{grid-template-columns:1fr;padding:10px}.dim{padding:14px}.scene-header{padding:14px 16px}.finding,.action{grid-template-columns:33px 1fr;gap:10px}}@media print{body{background:white;color:#111}.hero{padding:24px 0;background:#12353b!important;-webkit-print-color-adjust:exact;print-color-adjust:exact}.wrap{margin:16px auto;padding:0}.panel{box-shadow:none;border:0;padding:12px 0;margin-bottom:20px}.scene{break-inside:avoid}.dim,.finding,.action{break-inside:avoid}.evidence:not([open])>summary{display:none}.evidence:not([open])>.quote{display:block!important}.quote{display:block!important}.scene-header{background:#173b40!important;-webkit-print-color-adjust:exact;print-color-adjust:exact}}'''
def render(d):
    audit=d.get('audit') or {}
    if not audit.get('passed'):raise ValueError('audit未通过，拒绝生成正式报告')
    if not (3 <= len(d.get("findings") or []) <= 5): raise ValueError("关键发现必须3–5条")
    if not (3 <= len(d.get("recommendations") or []) <= 5): raise ValueError("行动建议必须3–5条")
    if not (d.get("scenes") or []): raise ValueError("至少需要一个场景")
    if not str(d.get('product_name') or '').strip():raise ValueError('缺少产品名称')
    for x in d['findings']:
        if not isinstance(x,dict) or not str(x.get('title','')).strip() or not str(x.get('detail','')).strip():raise ValueError('业务发现标题或内容为空')
    for x in d['recommendations']:
        if not isinstance(x,dict) or not str(x.get('title','')).strip() or not str(x.get('detail','')).strip():raise ValueError('行动建议标题或内容为空')
    for s in d['scenes']:
        if not isinstance(s,dict) or not str(s.get('name','')).strip():raise ValueError('场景名称为空')
        raw=s.get('dimensions') or {}
        substantive=0
        for label,aliases in DIMENSIONS:
            v=pick(raw,*aliases)
            if isinstance(v,dict):v=pick(v,'text','detail','value')
            if str(v or '').strip() and str(v).strip()!='暂无充分证据':substantive+=1
        if substantive<3:raise ValueError('场景八维度实质内容不足（少于3项）')
    findings=[]
    for i,x in enumerate((d.get('findings') or [])[:5],1):
        if not isinstance(x,dict):continue
        findings.append(f'<article class="finding"><span class="ordinal">{i:02d}</span><div><h3>{esc(x.get("title",""))}</h3><p>{esc(x.get("detail",""))}</p>{evidence(x.get("evidence"))}</div></article>')
    scenes=[]
    for s in (d.get('scenes') or []):
        if not isinstance(s,dict):continue
        raw=s.get('dimensions') or {}; dims=[]
        for idx,(label,aliases) in enumerate(DIMENSIONS,1):
            v=pick(raw,*aliases)
            if isinstance(v,dict):
                value=pick(v,'text','detail','value') or '暂无充分证据'; ev=evidence(v.get('evidence'))
            else:value=v or '暂无充分证据';ev=''
            dims.append(f'<div class="dim"><div class="dim-label">{idx:02d} / {label}</div><p>{esc(value)}</p>{ev}</div>')
        count=s.get('count');count_text=f'{esc(count)} 条评论' if count is not None else ''
        scenes.append(f'<article class="scene"><div class="scene-header"><h3>{esc(s.get("name","未命名场景"))}</h3><small>{count_text}</small></div><div class="dims">{"".join(dims)}</div></article>')
    actions=[]
    for i,x in enumerate((d.get('recommendations') or [])[:5],1):
        if not isinstance(x,dict):continue
        problem=pick(x,'problem');action=pick(x,'action');value=pick(x,'value')
        extra=''.join(f'<p class="meta"><b>{lab}：</b>{esc(v)}</p>' for lab,v in [('解决问题',problem),('具体行动',action),('用户价值',value)] if v)
        actions.append(f'<article class="action"><span class="ordinal">{i:02d}</span><div><h3>{esc(x.get("title",""))}</h3><p>{esc(x.get("detail",""))}</p>{extra}{evidence(x.get("evidence"))}</div></article>')
    name=esc(d.get('product_name') or '产品用户需求洞察报告');sub=esc(d.get('subtitle') or '基于真实用户反馈的产品洞察')
    def section(n,title,body):return f'<section class="panel"><div class="section-head"><span class="section-no">{n}</span><h2>{title}</h2></div>{body or "<p class=empty>暂无可展示内容</p>"}</section>'
    content=section('01','关键业务发现',''.join(findings))+section('02','场景级八维度分析',''.join(scenes))+section('03','行动建议',''.join(actions))
    return f'<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="report-template" content="amazon-review-locked-v1.5"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{name}｜用户需求洞察</title><style>{CSS}</style></head><body><header class="hero"><div class="hero-inner"><div class="eyebrow">PRODUCT INSIGHT REPORT</div><h1>{name}</h1><p>{sub}</p></div></header><main class="wrap">{content}</main></body></html>'
def main():
    p=argparse.ArgumentParser();p.add_argument('--data',required=True);p.add_argument('--out',required=True);a=p.parse_args()
    d=json.loads(pathlib.Path(a.data).read_text(encoding='utf-8'))
    out=pathlib.Path(a.out);out.parent.mkdir(parents=True,exist_ok=True);out.write_text(render(d),encoding='utf-8');print('HTML created:',out)
if __name__=='__main__':main()

---
name: amazon-review-full-analysis
description: Amazon及社媒评论全量需求洞察，Excel/CSV解析、结构化OCR记录合并、逐条标注审计、固定v1.5三板块HTML与会话追问。处理流程v1.6。
---

# Amazon Review 用户需求洞察 Skill｜处理流程 v1.6

## 不可违反的原则
- **唯一报告路径**：真实审计通过 → report_content.json → `scripts/render_html.py` → `scripts/validate_report.py --data report_content.json` → 交付HTML。禁止自写HTML或绕过校验。
- 报告顶部仅产品标题与简短副标题，正文仅3板块：关键业务发现3–5、场景级八维度、行动建议3–5。禁止新增排行榜、图表、附录、方法等独立板块。
- 全量逐条标注，不抽样；每条有效评论参与归并；低信息量依需求/场景/具体问题的语义判定，不以长度判定。
- **彻底取消 P0–P3**：不得计算等级、九宫格、频次档、严重度档；仅输出痛点主题提及数、占有效评论比例、频次排序、可核验低星关联数与证据。
- 不虚构星级、评论、来源、计数、工具执行、市场信息、退货率或认证。原始数据与推断区分。
- 默认美国市场；用户指定其他国家以指定市场为准；海外研究与概念图调用真实平台工具。

## 1. 输入与解析
- 表格 `.csv/.xlsx/.xlsm`：`python scripts/review_pipeline.py prepare --input INPUT --out RUN --file-index 1 --product-id PRODUCT`。
- 自动识别前10行合法表头，跳过非数据Sheet并记入manifest；CSV尝试UTF-8 BOM及GB18030；不支持的格式清楚报错。
- Title和Rating可缺失，Content为必需列；保留原始 title/content 及展示清洗版；编号 `F{文件号}S{sheet号}R{原始行号}`。输入行数、跳过页、空行、异常与唯一性均留档。
- 如果所有Sheet均无评论，失败并报告，不得伪称完成。

## 2. 截图OCR与真实合并（同一产品模式B）
- 平台实际可用的OCR负责**从图片提取文本**。本Skill不包含OCR引擎，不得宣称脚本自身能识别图片。
- 模型根据真实OCR输出逐条切分，人工或模型确认评论边界，生成符合 `references/ocr_records_example.json` 的JSON：`reviews[]` 每项 `source_file`、`source_ref`、`content`，可选 `title`、`rating`、`boundary_confidence`。一图多评论必须分多项；不确定边界标 `uncertain` 并在结果中说明。
- 执行 `python scripts/review_pipeline.py merge-ocr --parsed RUN/parsed_reviews.csv --ocr-json ocr_records.json --out MERGED --file-index 2`。
- 合并生成新的 `MERGED/parsed_reviews.csv` 和 manifest。截图记录具有独立编号、source_type=screenshot、source_ref；同正文疑似重复仅标记 `duplicate_candidate`，不擅自删除。
- **只以合并后的 parsed_reviews.csv 为后续唯一输入**；若OCR结果未落CSV，不能声称已纳入统计。OCR未确认记录必须披露数量。
- 不同产品模式A：各自独立运行并交付独立HTML，不得混合；同品类不等于同商品。

## 3. 逐条标注与跨批归并
- 按 `references/compact_annotation_contract.md` 对每条 parsed 评论生成一条 JSONL，保存为 annotations.jsonl。字段包括 record_id、classification、reason、main_scene、secondary_scenes、pain_points、evidence、annotation_version、product_id、source_type。
- annotation_version 必须与 parsed 一致；source_type 与 parsed 一致。不能把缺星级评论当作低星。
- 常规每批100条，超上下文则缩小并保存每批文件，合并后按record_id检查重复及遗漏。保留未归类；同一评论多个不同痛点分别计数、同主题只计一次。
- `references/rules_v5_frozen_v1.2.md` 是**旧商品历史语义参考**，不可把旧牙刷架场景/痛点码硬套新商品。新商品使用 XS_/XP_ 语义命名，跨批统一同义主题。
- `python scripts/review_pipeline.py audit --parsed MERGED/parsed_reviews.csv --annotations annotations.jsonl --out AUDIT`；只有 audit.json passed=true 才继续。
- 主题统计 `theme_stats.csv` 仅含频次、分母、占比、低星数、record_ids，不含任何优先级字段。
- 注意：审计只能保证结构和计数，不能自动证明语义归并正确；必要时对同义主题做人工复核。

## 4. 固定HTML与交付
- 基于真实审计结果生成 `report_content.json`，必须包含 `product_name`、`audit:{passed:true}`、`findings` 3–5、`scenes`、`recommendations` 3–5。每个场景八维顺序：人群定位、空间、情境、用户目标、产品需求、当前痛点、未被满足的需求、优化建议。
- 必须从真实 audit.json 读取计数；报告副标题不可手写虚假的截图数量。关键发现和建议引用真实评论编号、原文。
- `python scripts/render_html.py --data report_content.json --out report.html`
- `python scripts/validate_report.py report.html --data report_content.json`
- 校验器将报告与渲染器重放结果比较，并拦截空壳场景；不通过不得交付。
- 首轮必须交付**用户实际可访问**的 report.html 文件或链接。上传云盘需遵守平台权限；若无法上传，直接提供可用附件；若都不行，明确失败，不能只给内部路径。追问无需重复上传同一报告。

## 5. 会话追问与市场分析
- 复用本轮保存的 parsed、annotations、audit、theme_stats、report_content；无需重复全量分析。
- 支持满意度、购买动机、画像、空间用途、JTBD、功能满足度、原生/方案痛点、跨商品对比（需多个商品）、迭代建议、概念图（需实际图像工具）等方向。
- 数量问题应从逐条标注重新聚合，不能从摘要反推。标明分母、去重口径、证据；区分【评论事实】【外部来源】【合理推断】【待验证假设】。
- 外部市场搜索、法规、竞品和概念图必须真实调用可用工具，缺工具说明限制。不得虚构退货率或市场规模。

## 6. 测试与性能
- 100条180秒仅是历史目标，已知109条端到端曾超过该目标，不得声称达标。记录真实耗时，缺失则写未测。
- 1000条仅解析层曾验证；完整分析不宣称已验证。跨批稳定性、截图切分准确率和平台端到端必须在部署环境验收。
- 每次修改先保留备份，失败不破坏原版；保留真实验收数据，不能以自我评价替代结果。
